<?php

// Text
$_['text_title'] = 'Secure payment via Stripe';
$_['text_payment_for_products'] = 'Payment for products';
$_['text_loading'] = 'Loading...';

// Button
$_['button_confirm'] = 'Confirm';

// Error
$_['error_order_id'] = 'No order ID in the session!';
$_['error_payment_method'] = 'Payment method is incorrect!';