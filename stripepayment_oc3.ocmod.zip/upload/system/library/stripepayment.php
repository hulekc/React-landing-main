<?php

require_once(DIR_SYSTEM . 'library/stripe-php-15.8.0/init.php');

use Stripe\Stripe;

class stripepayment {

    public function __construct($registry) {
        $config = $registry->get('config');
        $stripepayment_secret_key = $config->get('payment_stripepayment_secret_key');
        Stripe::setApiKey($stripepayment_secret_key);
        Stripe::setAppInfo("stripepayment (Stripe Checkout Module)", "1.2", "https://www.opencart.com/index.php?route=marketplace/extension/info&extension_id=46416");
    }
}
