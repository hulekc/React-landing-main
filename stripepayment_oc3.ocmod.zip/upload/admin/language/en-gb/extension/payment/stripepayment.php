<?php

// Heading
$_['heading_title'] = 'Stripe Checkout Module';

// Tab
$_['tab_settings'] = 'Settings';
$_['tab_help'] = 'Help';

// Text
$_['text_stripepayment'] = '<a target="_BLANK" href="https://stripe.com/"><img src="view/image/payment/stripepayment/stripe-logo.png" alt="Stripe" title="Stripe" style="border: 1px solid #EEEEEE; max-width:100px;" /></a>';
$_['text_success'] = 'Success: You have modified Stripe Checkout Module details!';
$_['text_edit'] = 'Edit Stripe Checkout Module';
$_['text_extension'] = 'Extensions';
$_['text_home'] = 'Home';

// Entry
$_['entry_public_key'] = 'Public API Key';
$_['entry_secret_key'] = 'Secret API Key';
$_['entry_signing_secret_key'] = 'Signing Secret API Key';
$_['entry_success_url'] = 'Success URL';
$_['entry_cancel_url'] = 'Cancel URL';
$_['entry_order_status'] = 'Order Status After Payment';
$_['entry_logging'] = 'Debug Logging';
$_['entry_status'] = 'Status';
$_['entry_sort_order'] = 'Sort Order';

// Help
$_['help_public_key'] = "Something like pk_live_abc1De2f... or pk_test_abc1De2f...";
$_['help_secret_key'] = "Something like sk_live_ab2cD3ef... or sk_test_ab2cD3ef...";
$_['help_signing_secret_key'] = "Something like whsec_a1bcDe3f...";
$_['help_logging'] = 'Enabling debug will write sensitive data to a log file. You should always disable unless instructed otherwise.';

// Error
$_['error_warning'] = 'Warning: Please check the form carefully for errors!';
$_['error_permission'] = 'Warning: You do not have permission to modify Stripe Checkout Module!';
$_['error_public_key'] = 'Public API Key Required!';
$_['error_secret_key'] = 'Secret API Key Required!';
$_['error_signing_secret_key'] = 'Signing Secret API Key Required!';
$_['error_success_url'] = 'Success URL Required!';
$_['error_cancel_url'] = 'Cancel URL Required!';
$_['error_php_version'] = 'PHP version 5.6.0 or higher is required!';
