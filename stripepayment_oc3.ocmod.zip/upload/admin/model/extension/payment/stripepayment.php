<?php

class ModelExtensionPaymentstripepayment extends Model {
	public function install() {
        $this->log('stripepayment module installed');
    }

	public function uninstall() {
		$this->log('stripepayment module uninstalled');
	}

	public function log($data) {
        $log = new Log('stripepayment.log');
        $log->write(json_encode($data));
	}
}
