<?php
class ModelExtensionPaymentstripepayment extends Model {
	public function getMethod($address, $total) {
		$this->load->language('extension/payment/stripepayment');

        $status = $total > 0.00;

		$method_data = [];

		if ($status) {
			$method_data = [
				'code'       => 'stripepayment',
				'title'      => $this->language->get('text_title'),
				'terms'      => '',
				'sort_order' => $this->config->get('payment_stripepayment_sort_order')
			];
		}

		return $method_data;
	}
}
