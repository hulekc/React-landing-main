<?php

// Heading
$_['heading_title'] = 'Moduł Stripe Checkout';

// Tab
$_['tab_settings'] = 'Ustawienia';
$_['tab_help'] = 'Pomoc';

// Text
$_['text_stripepayment'] = '<a target="_BLANK" href="https://stripe.com/"><img src="view/image/payment/stripepayment/stripe-logo.png" alt="Stripe" title="Stripe" style="border: 1px solid #EEEEEE; max-width:100px;" /></a>';
$_['text_success'] = 'Sukces: Zmodyfikowano szczegóły modułu Stripe Checkout!';
$_['text_edit'] = 'Edytuj moduł Stripe Checkout';
$_['text_extension'] = 'Rozszerzenia';
$_['text_home'] = 'Strona główna';

// Entry
$_['entry_public_key'] = 'Klucz publiczny API';
$_['entry_secret_key'] = 'Klucz tajny API';
$_['entry_signing_secret_key'] = 'Klucz tajny podpisu API';
$_['entry_success_url'] = 'URL sukcesu';
$_['entry_cancel_url'] = 'URL anulowania';
$_['entry_order_status'] = 'Status zamówienia po płatności';
$_['entry_logging'] = 'Logowanie debugowania';
$_['entry_status'] = 'Status';
$_['entry_sort_order'] = 'Kolejność sortowania';

// Help
$_['help_public_key'] = "Coś w stylu pk_live_abc1De2f... lub pk_test_abc1De2f...";
$_['help_secret_key'] = "Coś w stylu sk_live_ab2cD3ef... lub sk_test_ab2cD3ef...";
$_['help_signing_secret_key'] = "Coś w stylu whsec_a1bcDe3f...";
$_['help_logging'] = 'Włączenie debugowania zapisze poufne dane do pliku dziennika. Należy je zawsze wyłączyć, chyba że zalecano inaczej.';

// Error
$_['error_warning'] = 'Uwaga: Proszę dokładnie sprawdzić formularz pod kątem błędów!';
$_['error_permission'] = 'Uwaga: Nie masz uprawnień do modyfikowania modułu Stripe Checkout!';
$_['error_public_key'] = 'Wymagany jest klucz publiczny API!';
$_['error_secret_key'] = 'Wymagany jest klucz tajny API!';
$_['error_signing_secret_key'] = 'Wymagany jest klucz tajny podpisu API!';
$_['error_success_url'] = 'Wymagany jest URL sukcesu!';
$_['error_cancel_url'] = 'Wymagany jest URL anulowania!';
$_['error_php_version'] = 'Wymagana jest wersja PHP 5.6.0 lub wyższa!';
