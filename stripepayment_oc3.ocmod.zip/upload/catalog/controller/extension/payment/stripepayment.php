<?php

use Stripe\Checkout\Session;
use Stripe\Exception\SignatureVerificationException;
use Stripe\Webhook;
class ControllerExtensionPaymentstripepayment extends Controller {

    public function __construct($registry)
    {
        parent::__construct($registry);
		$this->load->language('extension/payment/stripepayment');
        $this->load->library('stripepayment');
    }

    public function index() {
		$data['l'] = $this->language;
        $data['payment_stripepayment_public_key'] = $this->config->get('payment_stripepayment_public_key');

		return $this->load->view('extension/payment/stripepayment', $data);
	}

    public function createCheckoutSession()
    {
        if ($this->request->server['REQUEST_METHOD'] != 'POST'){
            http_response_code(400);
            exit();
        }

        $json = [];

        if (!isset($this->session->data['order_id'])) {
            $json['error'] = $this->language->get('error_order');
        }

        if (!isset($this->session->data['payment_method']) || $this->session->data['payment_method']['code'] != 'stripepayment') {
            $json['error'] = $this->language->get('error_payment_method');
        }

        if (!$json) {
            $this->load->model('checkout/order');
            $this->load->model('account/order');

            $order_id = $this->session->data['order_id'];
            $order_info = $this->model_checkout_order->getOrder($order_id);
            $currency_code = $this->session->data['currency'];
            $currency_value = $this->currency->getValue($currency_code);
            $order_total = round(($order_info['total'] * $currency_value), 2);

            $products = $this->model_account_order->getOrderProducts($order_id);
            if (!is_array($products) || count($products) == 0) {
                $products = $this->cart->getProducts();
            }

            // Calculate products total and create line items
            $line_items = [];
            $products_total = 0;
            if (is_array($products)) {
                foreach ($products as $product) {
                    $unit_amount = round((($product['price'] + $product['tax']) * $currency_value), 2);
                    $quantity = intval(round($product['quantity']));
                    $products_total += $unit_amount * $quantity;
                    $line_items[] = [
                        "price_data" => [
                            "currency" => strtolower($currency_code),
                            "unit_amount" => intval($unit_amount * 100),
                            "product_data" => [
                                "name" => str_replace(["'", '"', '&#39;', '&'], '', htmlspecialchars_decode($product['name'])),
                                "images" => [],
                            ],
                        ],
                        "quantity" => $quantity,
                    ];
                }
            }

            // Get shipping cost
            $shipping_cost = 0;
            $totals = $this->model_checkout_order->getOrderTotals($order_id);
            foreach($totals as $total) {
                if ($total['code'] == 'shipping') {
                    $shipping_cost = $total['value'];
                    break;
                }
            }
            $shipping_cost = round($shipping_cost * $currency_value, 2);

            // Build checkout parameters
            $params = [
                'mode' => 'payment',
                'billing_address_collection' => 'required',
                'success_url' => $this->config->has('payment_stripepayment_success_url') ? $this->config->get('payment_stripepayment_success_url') : '',
                'cancel_url' => $this->config->has('payment_stripepayment_cancel_url') ? $this->config->get('payment_stripepayment_cancel_url') : '',
                'metadata' => ['order_id' => $order_id],
            ];
            if (!empty($order_info['email'])) {
                $params['customer_email'] = $order_info['email'];
            }

            // Check if total is correct
            if ($products_total > 0 && $order_total == $products_total + $shipping_cost){
                // Add line items and shipping options to checkout parameters
                $params['line_items'] = $line_items;
                if ($shipping_cost > 0) {
                    $params['shipping_options'] = [
                        [
                            'shipping_rate_data' => [
                                'type' => 'fixed_amount',
                                'fixed_amount' => [
                                    'amount' => intval($shipping_cost * 100),
                                    'currency' => strtolower($currency_code),
                                ],
                                'display_name' => isset($order_info['shipping_method']) ? $order_info['shipping_method'] : '',
                            ]
                        ]
                    ];
                }
            } else {
                // Invalid total
                $params['line_items'] = [
                    [
                        "price_data" => [
                            "currency" => strtolower($currency_code),
                            "unit_amount" => intval($order_total * 100),
                            "product_data" => [
                                "name" => $this->language->get('text_payment_for_products'),
                                "images" => [],
                            ],
                        ],
                        "quantity" => 1,
                    ]
                ];
            }

            // Create checkout session
            try {
                $checkout_session = Session::create($params);
                $json['id'] = $checkout_session->id;
            } catch (Exception $e) {
                $json['error'] = $e->getMessage();
                $this->log($e->getMessage());
            }
        }

        $this->response->addHeader('Content-Type: application/json');
        $this->response->setOutput(json_encode($json));
    }

    public function webhook(){

        $payload = @file_get_contents('php://input');
        $sig_header = $_SERVER['HTTP_STRIPE_SIGNATURE'];
        $endpoint_secret = $this->config->get('payment_stripepayment_signing_secret_key');

        try {
            $event = Webhook::constructEvent(
                $payload, $sig_header, $endpoint_secret
            );
        } catch (UnexpectedValueException $e) {
            // Invalid payload
            http_response_code(400);
            exit();
        } catch (SignatureVerificationException $e) {
            // Invalid signature
            http_response_code(403);
            exit();
        }

        $this->log($event);

        if ($event->type == 'checkout.session.completed') {

            $this->load->model('checkout/order');
            $this->load->model('extension/payment/stripepayment');

            $session = $event->data->object;
            $order_id = $session->metadata->order_id;

            /**
             * check current order status if no eq payment_stripepayment_order_status_id then confirm
             */
            $this->load->model('checkout/order');
            $orderInfo = $this->model_checkout_order->getOrder($order_id);
            $payment_stripepayment_order_status_id = $this->config->get('payment_stripepayment_order_status_id');
            if (
                $orderInfo &&
                $orderInfo['order_status_id'] == $payment_stripepayment_order_status_id
            ) {
                //nothing
            } else {
                $payment_status = isset($session->payment_status) ? $session->payment_status : '';
                $amount_total = isset($session->amount_total) ? $session->amount_total : 0;
                $currency = isset($session->currency) ? $session->currency : '';
                $session_id = isset($session->id) ? $session->id : '';
                $message = sprintf("Order processed by Stripe. payment_status: '%s',  amount_total: '%s', currency: '%s', session_id: '%s'", $payment_status, $amount_total/100, $currency, $session_id);
                $this->model_checkout_order->addOrderHistory($order_id, $payment_stripepayment_order_status_id, $message, false);
            }
        }
    }

    protected function log($data) {
        if ($this->config->has('payment_stripepayment_logging') && $this->config->get('payment_stripepayment_logging')) {
            $log = new Log('stripepayment.log');
            $log->write(json_encode($data));
        }
    }
}
