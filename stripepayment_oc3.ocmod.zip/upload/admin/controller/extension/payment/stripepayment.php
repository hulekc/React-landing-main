<?php

use Stripe\Stripe;

class ControllerExtensionPaymentstripepayment extends Controller {

	private $error = [];

    const NO_DEFAULT_VALUE = 'no_default_value';

	public function index() {
		$this->load->model('setting/setting');
		$this->load->model('extension/payment/stripepayment');
		$this->load->model('localisation/order_status');

		$this->load->language('extension/payment/stripepayment');
		$data['l'] = $this->language;

		$this->document->setTitle($this->language->get('heading_title'));

		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validate()) {
			$this->model_setting_setting->editSetting('payment_stripepayment', $this->request->post);
			$this->session->data['success'] = $this->language->get('text_success');
            $this->response->redirect($this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=payment', true));
		}

        // Check PHP version
        if (version_compare(phpversion(), '5.6.0', '<') && !isset($this->error['warning'])) {
            $this->error['warning'] = $this->language->get('error_php_version');
        }

		$data['breadcrumbs'] = [];

		$data['breadcrumbs'][] = [
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
		];

		$data['breadcrumbs'][] = [
			'text' => $this->language->get('text_extension'),
            'href' => $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=payment', true)
		];

		$data['breadcrumbs'][] = [
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('extension/payment/stripepayment', 'user_token=' . $this->session->data['user_token'], true)
        ];

		$data['action'] = $this->url->link('extension/payment/stripepayment', 'user_token=' . $this->session->data['user_token'], true);

        $data['cancel'] = $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=payment', true);

        $order_statuses = $this->model_localisation_order_status->getOrderStatuses();
        $data['order_statuses'] = $order_statuses;

        $keys = [
            'payment_stripepayment_public_key' => '',
            'payment_stripepayment_secret_key' => '',
            'payment_stripepayment_signing_secret_key' => '',
            'payment_stripepayment_success_url' => HTTPS_CATALOG . 'index.php?route=checkout/success',
            'payment_stripepayment_cancel_url' => HTTPS_CATALOG . 'index.php?route=checkout/failure',
            'payment_stripepayment_status' => 0,
            'payment_stripepayment_sort_order' => 0,
            'payment_stripepayment_order_status_id' => $this->findDefaultOrderStatusId($order_statuses),
            'payment_stripepayment_logging' => 0,
        ];

        foreach ($keys as $key => $default) {
            if (isset($this->request->post[$key])) {
                $data[$key] = $this->request->post[$key];
            } elseif ($this->config->has($key)) {
                $data[$key] = $this->config->get($key);
            } elseif ($default !== self::NO_DEFAULT_VALUE) {
                $data[$key] = $default;
            }
        }

        $data['error_warning'] = $this->getError('warning');
        $data['error_public_key'] = $this->getError('public_key');
        $data['error_secret_key'] = $this->getError('secret_key');
        $data['error_signing_secret_key'] = $this->getError('signing_secret_key');
        $data['error_success_url'] = $this->getError('success_url');
        $data['error_cancel_url'] = $this->getError('cancel_url');

		if (isset($this->session->data['success'])) {
			$data['success'] = $this->session->data['success'];
			unset($this->session->data['success']);
		} else {
			$data['success'] = '';
		}

		$data['user_token'] = $this->session->data['user_token'];

		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('extension/payment/stripepayment', $data));
	}

    function getError($key, $default = '') {
        return isset($this->error[$key]) ? $this->error[$key] : $default;
    }

    private function findDefaultOrderStatusId($order_statuses) {
        if (!is_array($order_statuses) || empty($order_statuses)) {
            return self::NO_DEFAULT_VALUE;
        }
        foreach ($order_statuses as $status) {
            if (strtolower($status['name']) === 'processing') {
                return $status['order_status_id'];
            }
        }
        return $order_statuses[0]['order_status_id'];
    }

	public function install() {
		if ($this->user->hasPermission('modify', 'extension/payment/stripepayment')) {
			$this->load->model('extension/payment/stripepayment');

			$this->model_extension_payment_stripepayment->install();
		}
	}

	public function uninstall() {
		if ($this->user->hasPermission('modify', 'extension/payment/stripepayment')) {
			$this->load->model('extension/payment/stripepayment');

			$this->model_extension_payment_stripepayment->uninstall();
		}
	}

	protected function validate() {
		if (!$this->user->hasPermission('modify', 'extension/payment/stripepayment')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}

        if (!$this->request->post['payment_stripepayment_public_key']) {
            $this->error['public_key'] = $this->language->get('error_public_key');
        }

        if (!$this->request->post['payment_stripepayment_secret_key']) {
            $this->error['secret_key'] = $this->language->get('error_secret_key');
        }

        if (!$this->request->post['payment_stripepayment_signing_secret_key']) {
            $this->error['signing_secret_key'] = $this->language->get('error_signing_secret_key');
        }

        if (!$this->request->post['payment_stripepayment_success_url']) {
            $this->error['success_url'] = $this->language->get('error_success_url');
        }

        if (!$this->request->post['payment_stripepayment_cancel_url']) {
            $this->error['cancel_url'] = $this->language->get('error_cancel_url');
        }

		if ($this->error && !isset($this->error['warning'])) {
			$this->error['warning'] = $this->language->get('error_warning');
		}

		return !$this->error;
	}
}
