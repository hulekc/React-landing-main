<?php

// Heading
$_['heading_title'] = 'Πρόσθετο Stripe Checkout';

// Tab
$_['tab_settings'] = 'Ρυθμίσεις';
$_['tab_help'] = 'Βοήθεια';

// Text
$_['text_stripepayment'] = '<a target="_BLANK" href="https://stripe.com/"><img src="view/image/payment/stripepayment/stripe-logo.png" alt="Stripe" title="Stripe" style="border: 1px solid #EEEEEE; max-width:100px;" /></a>';
$_['text_success'] = 'Επιτυχία: Έχετε τροποποιήσει τις λεπτομέρειες του πρόσθετου Stripe Checkout!';
$_['text_edit'] = 'Επεξεργασία πρόσθετου Stripe Checkout';
$_['text_extension'] = 'Επεκτάσεις';
$_['text_home'] = 'Αρχική σελίδα';

// Entry
$_['entry_public_key'] = 'Δημόσιο Κλειδί API';
$_['entry_secret_key'] = 'Μυστικό Κλειδί API';
$_['entry_signing_secret_key'] = 'Μυστικό Κλειδί Υπογραφής API';
$_['entry_success_url'] = 'URL Επιτυχίας';
$_['entry_cancel_url'] = 'URL Ακύρωσης';
$_['entry_order_status'] = 'Κατάσταση Παραγγελίας Μετά την Πληρωμή';
$_['entry_logging'] = 'Καταγραφή Σφαλμάτων';
$_['entry_status'] = 'Κατάσταση';
$_['entry_sort_order'] = 'Σειρά Ταξινόμησης';

// Help
$_['help_public_key'] = "Κάτι σαν pk_live_abc1De2f... ή pk_test_abc1De2f...";
$_['help_secret_key'] = "Κάτι σαν sk_live_ab2cD3ef... ή sk_test_ab2cD3ef...";
$_['help_signing_secret_key'] = "Κάτι σαν whsec_a1bcDe3f...";
$_['help_logging'] = 'Η ενεργοποίηση της καταγραφής θα αποθηκεύσει ευαίσθητα δεδομένα σε ένα αρχείο καταγραφής. Πρέπει πάντα να είναι απενεργοποιημένο εκτός αν συνιστάται διαφορετικά.';

// Error
$_['error_warning'] = 'Προειδοποίηση: Ελέγξτε προσεκτικά τη φόρμα για σφάλματα!';
$_['error_permission'] = 'Προειδοποίηση: Δεν έχετε άδεια να τροποποιήσετε το πρόσθετο Stripe Checkout!';
$_['error_public_key'] = 'Απαιτείται Δημόσιο Κλειδί API!';
$_['error_secret_key'] = 'Απαιτείται Μυστικό Κλειδί API!';
$_['error_signing_secret_key'] = 'Απαιτείται Μυστικό Κλειδί Υπογραφής API!';
$_['error_success_url'] = 'Απαιτείται URL Επιτυχίας!';
$_['error_cancel_url'] = 'Απαιτείται URL Ακύρωσης!';
$_['error_php_version'] = 'Απαιτείται έκδοση PHP 5.6.0 ή νεότερη!';
